function saludar(){

    let nombre = document.getElementById('nombrePersona').value;

    document.getElementById('saludo').innerHTML ='<p>Hola '  +nombre+' , un gusto saludarte</p>';

    return false;
}

